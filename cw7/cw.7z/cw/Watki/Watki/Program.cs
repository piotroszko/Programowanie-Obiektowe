﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Watki
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread thr = new Thread(Licz);
            thr.Start();
            for (int i=0;i <= 1000; i++)
            {
                Console.WriteLine("program1:" + i);
            }
            Console.ReadKey();
        }
        public static void Licz()
        {
            for (int i = 0; i <= 1000; i++)
            {
                Console.WriteLine("Watek:" + i);
            }
        }

    }
}
