﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Zadania
{
    class Program
    {
        static void Main(string[] args)
        {
            Robot robot1 = new Robot("Robot1",0,0);
            Platforma platforma1 = new Platforma(5, 5);
            robot1.Wyswietl(platforma1,robot1._zwrot);
            robot1.RuszDo(platforma1, 3, 3);
            Console.ReadKey();
        }

    }
    class Robot
    {
        public string nazwaRobota = "";
        public int bateria { get; private set; }
        public zwrot _zwrot;
        public int x = 0;
        public int y = 0;

        public Robot(string nazwaRobota, int x, int y)
        {
            this.nazwaRobota = nazwaRobota;
            this.bateria = 100;
            this._zwrot = zwrot.B;
            this.x = x;
            this.y = y;
        }
        void BateriaSpadek()
        {
            this.bateria = bateria - 1;
        }
        public void Ruch()
        {
             if (this._zwrot == zwrot.B)
            {
                this.y++;
            }
            else if (this._zwrot == zwrot.T)
            {
                this.y--;
            }
            else if (this._zwrot == zwrot.L)
            {
                this.x--;
            }
            else if (this._zwrot == zwrot.R)
            {
                this.x++;
            }
        }
        public void Obroc(zwrot wKtoraStrone)
        {
            if (wKtoraStrone == zwrot.B)
            {
                this._zwrot = zwrot.B;
            } else if (wKtoraStrone == zwrot.L)
            {
                this._zwrot = zwrot.L;
            } else if (wKtoraStrone == zwrot.T)
            {
                this._zwrot = zwrot.T;
            } else if (wKtoraStrone == zwrot.R)
            {
                this._zwrot = zwrot.R;
            }
        }
        bool Sprawdz(Platforma platformaTmp)
        {
            if (this.x == 0 && this.y == 0)
            {
                return true;
            }
            else if (this._zwrot == zwrot.B)
            {
                if (this.y + 1 > platformaTmp.width)
                {
                    return false;
                }
                else
                {
                    return true;
                }
                
            }
            else if (this._zwrot == zwrot.T)
            {
                if (this.y - 1 < 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else if (this._zwrot == zwrot.L)
            {
                if (this.x - 1 < 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                if (this.x + 1 > platformaTmp.length)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        public void RuszDo(Platforma platformaTmp, int xTmp,int yTmp)
        {
            while(this.y != yTmp && this.x != xTmp) {
                if (this.y < yTmp)
                {
                    this.Obroc(zwrot.B);
                    if (this.Sprawdz(platformaTmp) == true)
                    {
                        this.BateriaSpadek();
                        this.Ruch();
                        this.Wyswietl(platformaTmp, zwrot.B);
                        Thread.Sleep(1000);
                    } else
                    {
                        Console.WriteLine("Blad ! Proba wyjsca poza platforme!");
                        break;
                    }

                } else if (this.y > yTmp)
                {
                    this.Obroc(zwrot.T);
                    if (this.Sprawdz(platformaTmp) == true)
                    {
                        this.BateriaSpadek();
                        this.Ruch();
                        this.Wyswietl(platformaTmp,zwrot.T);
                        Thread.Sleep(1000);
                    } else
                    {
                        Console.WriteLine("Blad ! Proba wyjsca poza platforme!");
                        break;
                    }
                }
                else if (this.x > xTmp)
                {
                    this.Obroc(zwrot.L);
                    if (this.Sprawdz(platformaTmp) == true)
                    {
                        this.BateriaSpadek();
                        this.Ruch();
                        this.Wyswietl(platformaTmp,zwrot.L);
                        Thread.Sleep(1000);
                    } else
                    {
                        Console.WriteLine("Blad ! Proba wyjsca poza platforme!");
                        break;
                    }
                }
                else if (this.x < xTmp)
                {
                    this.Obroc(zwrot.R);
                    if (this.Sprawdz(platformaTmp) == true)
                    {
                        this.BateriaSpadek();
                        this.Ruch();
                        this.Wyswietl(platformaTmp,zwrot.R);
                        Thread.Sleep(1000);
                    } else
                    {
                        Console.WriteLine("Blad ! Proba wyjsca poza platforme!");
                        break;
                    }
                }
            }
            if (this.y == yTmp && this.x == xTmp)
            {
                Console.WriteLine("Udane dojscie do celu!");
            }
        }
        public void Wyswietl (Platforma platformaTmp,zwrot zwrotTmp)
        {
            Console.Clear();
            for (int i = 0; i < platformaTmp.width; i++)
            {
                for (int j = 0; j < platformaTmp.length; j++)
                {
                    if (i == this.x && j == this.y)
                    {
                        if (zwrotTmp == zwrot.B)
                        {
                            Console.Write("↓");
                        }
                        if (zwrotTmp == zwrot.T)
                        {
                            Console.Write("↑");
                        }
                        if (zwrotTmp == zwrot.L)
                        {
                            Console.Write("←");
                        }
                        if (zwrotTmp == zwrot.R)
                        {
                            Console.Write("→");
                        }
                    } else
                    {
                        Console.Write("O");
                    }
                }
                Console.WriteLine("");
            }
        }
    }
    public enum zwrot {T,B,R,L };
    class Platforma
    {
        public int length;
        public int width;

        public Platforma(int length, int width)
        {
            this.length = length;
            this.width = width;
        }
    }
}
