﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cw61
{
    class pracownik
    {
        public virtual void Pracuj() {
            Console.WriteLine("logowanie");
        }
    }
}
