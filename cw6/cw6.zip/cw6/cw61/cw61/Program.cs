﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cw61
{
    class Program
    {
        static void Main(string[] args)
        {
            pracownik p = new Programista();
            p.Pracuj();
            Console.ReadKey();
        }
    }
}
