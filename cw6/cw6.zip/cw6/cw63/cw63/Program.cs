﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cw63
{
    class Program
    {
        static void Main(string[] args)
        {
            List<pracownik> p = new List<pracownik>();
            Programista p1 = new Programista();
            Ksiegowy p2 = new Ksiegowy();
            Projektant p3 = new Projektant();
            p.Add(p1);
            p.Add(p2);
            p.Add(p3);
            foreach (pracownik n in p)
            {
                n.Pracuj();
            }
            Console.ReadKey();
        }
    }

}
