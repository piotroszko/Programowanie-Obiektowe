﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cw63
{
    class pracownik
    {
        public virtual void Pracuj()
        {
            Console.WriteLine("pracownik pracuje");
        }
    }
    class Programista : pracownik
    {
        public override void Pracuj()
        {
            Console.WriteLine("Programista pracuje");
        }
    }
    class Projektant : pracownik
    {
        public override void Pracuj()
        {
            Console.WriteLine("Projektant pracuje");
        }
    }
    class Ksiegowy : pracownik
    {
        public override void Pracuj()
        {
            Console.WriteLine("Ksiegowy pracuje");
        }
    }
}
