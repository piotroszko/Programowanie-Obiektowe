﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cw62
{
    abstract class Figura
    {
        protected int a,b,c;

        protected Figura(int a, int b, int c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public abstract int Pole();
    }
    class Kwadrat : Figura
    {
        public Kwadrat(int a, int b, int c) : base(a, b, c)
        {
        }

        public override int Pole()
        {
            int pole = this.a * this.a;
            return pole;
        }
    }
    class Trojkat : Figura
    {
        public Trojkat(int a, int b, int c) : base(a, b, c)
        {
        }
        public override int Pole()
        {
            int pole = Convert.ToInt32(this.a * this.b * 0.5);
            return pole;
        }
    }
}
