﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Konto
{
    class Program
    {
        static void Main(string[] args)
        {
            Konto piotr = new Konto(2000, 932324);
            piotr.WyplataWBankomacie(200);
        }
    }
    class Konto
    {
        public int saldoPoczatkowe;
        public int saldoKoncowe;
        public int PESEL;

        public Konto(int saldoPoczatkowe, int pESEL)
        {
            this.saldoPoczatkowe = saldoPoczatkowe;
            this.saldoKoncowe = saldoPoczatkowe;
            PESEL = pESEL;
        }
        public Konto[] Przelew (Konto[] kontaPrzelew,int kowotaPrzelewu)
        {
            Konto[] tmpKonta = kontaPrzelew;
            tmpKonta[0].saldoKoncowe = kontaPrzelew[0].saldoKoncowe - kowotaPrzelewu;
            tmpKonta[1].saldoKoncowe = kontaPrzelew[1].saldoKoncowe + kowotaPrzelewu;
            return tmpKonta;
        }
        public void WplataWKasie (int kwotaWplaty)
        {
            this.saldoKoncowe = saldoKoncowe + kwotaWplaty;
            DodajLog(" Wplata w kasie na kwote: " + kwotaWplaty + "   Saldo koncowe:" + this.saldoKoncowe );
        }
        public void WyplataWKkasie(int kwotaWyplaty)
        {
            this.saldoKoncowe = saldoKoncowe - kwotaWyplaty;
            DodajLog(" Wyplata w kasie na kwote: " + kwotaWyplaty + "   Saldo koncowe:" + this.saldoKoncowe);
        }
        public void WyplataWBankomacie(int kwotaWyplaty) {
            this.saldoKoncowe = saldoKoncowe - kwotaWyplaty;
            DodajLog(" Wyplata w bankomacie na kwote: " + kwotaWyplaty + "   Saldo koncowe:" + this.saldoKoncowe);
        }
        public void PlatnoscKarta(int kwotaZaplaty) {
            this.saldoKoncowe = saldoKoncowe - kwotaZaplaty;
            DodajLog(" Platnosc karta na kwote: " + kwotaZaplaty + "   Saldo koncowe:" + this.saldoKoncowe);
        }
        public void DodajLog(string opis)
        {
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(@"D:\PRoszkowski\zaj4\Konto\Konto\Logi\" + this.PESEL + ".txt", true))
            {
                file.WriteLine(DateTime.Now + " : == : " + opis);
            }
        }
    }
}
