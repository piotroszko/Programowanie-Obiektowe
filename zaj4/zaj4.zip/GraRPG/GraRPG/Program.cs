﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraRPG
{
    class Bohater
    {
        public string imie;
        public int zywotnosc;
        public int punktyTaktyki;
        public bool szal=false;

        protected Bohater(string imie, int zywotnosc, int punktyTaktyki)
        {
            this.imie = imie;
            this.zywotnosc = zywotnosc;
            this.punktyTaktyki = punktyTaktyki;
        }
        public void SprawdzZycie()
        {
            if (zywotnosc > 0)
            {
                this.zywotnosc = 0;
            }
            else if (zywotnosc > 100 && szal == false)
            {
                this.zywotnosc = 100;
            }
        }

    }
    class Wojownik : Bohater
    {
        public int sila;

        public Wojownik(string imie, int zywotnosc, int punktyTaktyki, int sila) : base(imie, zywotnosc, punktyTaktyki)
        {
            this.imie = imie;
            this.punktyTaktyki = punktyTaktyki;
            this.sila = sila;

            if (zywotnosc < 0)
            {
                this.zywotnosc = 0;
            }
            else if (zywotnosc > 100)
            {
                this.zywotnosc = 100;
            }
            else
            {
                this.zywotnosc = zywotnosc;
            }
        }
        public int MocAtaku() {
            if (this.zywotnosc <= 20 && szal == false) {
                this.zywotnosc = 150;
                this.szal = true;
            }
            int mocAtaku = this.sila * this.punktyTaktyki * (this.zywotnosc / 100);
            return mocAtaku;
        }
    }
    class Lucznik : Bohater
    {
        public int zrecznosc;

        public Lucznik(string imie, int zywotnosc, int punktyTaktyki, int zrecznosc) : base(imie, zywotnosc, punktyTaktyki)
        {
            this.imie = imie;
            if (zywotnosc < 0)
            {
                this.zywotnosc = 0;
            }
            else if (zywotnosc > 100)
            {
                this.zywotnosc = 100;
            } else
            {
                this.zywotnosc = zywotnosc;
            }
            this.punktyTaktyki = punktyTaktyki;
            this.zrecznosc = zrecznosc;
        }
        public int MocAtaku()
        {
            int mocAtaku = this.zrecznosc * this.punktyTaktyki * (zywotnosc / 100);

            return mocAtaku;
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Wojownik Aragorn = new Wojownik("Aragorn",100,3,10);
            Lucznik Legolas = new Lucznik("Legolas",100,3,10);
            Console.WriteLine("Aragorn moc ataku: "+Aragorn.MocAtaku() + "       Reszta statystyk: "+ Aragorn.zywotnosc +" "+ Aragorn.imie +" "+ Aragorn.sila);
            Console.WriteLine("Legolas moc ataku: " + Legolas.MocAtaku() + "       Reszta statystyk: " + Legolas.zywotnosc + " " + Legolas.imie + " " + Legolas.zrecznosc);
            Console.WriteLine("===================================");
            Aragorn.zywotnosc = 20;
            Legolas.zywotnosc = -2;
            Legolas.SprawdzZycie();
            Console.WriteLine("Aragorn moc ataku: " + Aragorn.MocAtaku() + "       Reszta statystyk: " + Aragorn.zywotnosc);
            Console.WriteLine("Legolas moc ataku: " + Legolas.MocAtaku());
            Console.ReadKey();
        }
    }
}
