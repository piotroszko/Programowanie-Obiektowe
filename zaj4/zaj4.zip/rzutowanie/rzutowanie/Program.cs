﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rzutowanie
{
    class Program
    {
        static void Main(string[] args)
        {
            BaseClass myObj = new BaseClass();
            DerrivedClass derObj1 = (DerrivedClass)myObj;
            NextDerrivedClas NxtObj1 = (NextDerrivedClas)myObj;
            Console.ReadKey();
        }
    }
    class BaseClass
    {

    }
    class DerrivedClass : BaseClass
    {

    }
    class NextDerrivedClas : DerrivedClass
    {

    }
}
