﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace zaj4
{
    class Program
    {
        static void Main(string[] args)
        {
            Osoba osoba = new Osoba("Adam","Kowalski",2212,"Olsztyn");
            Osoba osoba2 = new Osoba("", "", 0, "");
            Student student = new Student("Adam","Kowalski",2212,"Olsztyn",2019,5,212131);
            Student student2 = new Student("Adam2", "Kowalski2", 22122, "Olsztyn2", 20192, 52, 2121312);
            osoba2 = student2;
            student.WypiszInfo();
            student.ObliczWiek();
            Console.ReadKey();
        }
    }
    class Osoba
    {
        protected string imie;
        protected string nazwisko;
        protected int rokUr;
        protected string miejsceZamieszkania;

        public Osoba(string imie, string nazwisko, int rokUr, string miejsceZamieszkania)
        {
            this.imie = imie;
            this.nazwisko = nazwisko;
            this.rokUr = rokUr;
            this.miejsceZamieszkania = miejsceZamieszkania;
        }
        public void Cos() { }
        public void WypiszInfo()
        {
            foreach (var method in typeof(Osoba).GetMethods())
                Console.WriteLine(method);
            foreach (var variables in typeof(Osoba).GetFields())
                Console.WriteLine(variables);
        }
        public void ObliczWiek()
        {
            var wiek = 2019 - this.rokUr;
            Console.WriteLine("Rok urodzenia:" + wiek.ToString());
        }
    }
    class Student : Osoba
    {
        public int rok;
        public int numerGrupy;
        public int numerAlbumu;
        public Student(string imie, string nazwisko, int rokUr,string miejsceZamieszkania, int rok, int numerGrupy,int numerAlbumu) : base(imie, nazwisko, rokUr, miejsceZamieszkania)
        {
            this.rok = rok;
            this.numerGrupy = numerGrupy;
            this.numerAlbumu = numerAlbumu;
        }
        public void WypiszInfo() {
            foreach (FieldInfo field in typeof(Student).GetFields())
            {
                Console.WriteLine(field.Name);
            }
        }
        
    }
    class StudentPierwszegoRoku : Student
    {
        public StudentPierwszegoRoku(string imie, string nazwisko, int rokUr, string miejsceZamieszkania, int rok, int numerGrupy, int numerAlbumu) : base(imie, nazwisko, rokUr, miejsceZamieszkania, rok, numerGrupy, numerAlbumu)
        {
        }
    }
}
