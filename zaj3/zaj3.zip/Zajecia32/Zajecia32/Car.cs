﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zajecia32
{
    class Car
    {
        public double pojemnoscSilnika;
        public string marka;
        public static int iloscKol;
        static Car()
        {
            iloscKol = 4;
        }
        public Car(double pojemnoscSilnika, string marka)
        {
            this.pojemnoscSilnika = pojemnoscSilnika;
            this.marka = marka;
            iloscKol = 4;
        }
        public Car Create()
        {
            Car carTmp = new Car(this.pojemnoscSilnika, this.marka);
            return carTmp;
        }
        ~Car() {
            MessageBox.Show("Zwalniam pamiec");
        }
    }
}
