﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekt2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] table = new int[2];
            try
            {
                table[25] = 2;
                throw new IndexOutOfRangeException();
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine("Blad: : "+ e.Message);
            }
            catch
            {
                Console.WriteLine("Blad inny!?");
            }
            finally
            {
                Console.WriteLine("Finally");
            }
            Console.ReadKey();
        }
    }
}
