﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cwiczenia
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Co chcesz zrobić? : 1.Dodawanie 2.Odejmowanie 3.Mnozenie 4.Dzielenie 5. Potegowanie 6.Pierwiastkowanie");
            Console.WriteLine("Podaj komende (1-6):");
            string tmpWiad = Console.ReadLine();
            int wybor = 0;
            try
            {
                wybor = Convert.ToInt32(tmpWiad);
            }
            catch
            {
                Console.WriteLine("Podales zla komende !");
            }
            if (wybor == 1)
            {
                Console.WriteLine("Wybrales dodawanie! Podaj liczbe a:");
                string tmpWiad1 = Console.ReadLine();
                Console.WriteLine("Podaj liczbe b:");
                string tmpWiad2 = Console.ReadLine();

                int a = 0;
                int b = 0;
                try
                {
                    a = Convert.ToInt32(tmpWiad1);
                    b = Convert.ToInt32(tmpWiad2);
                }
                catch
                {
                    Console.WriteLine("Podales zla liczbe !");
                }
                Console.WriteLine("Wynik dodawania {0} + {1} = {2}",a,b,a+b);
                Console.ReadKey();
            }
        }
    }
    class Obliczenia
    {
        private int Dodawanie(int a, int b) {
            int wynik = a + b;
            return wynik;
        }
        private int Odemowanie(int a, int b)
        {
            int wynik = a - b;
            return wynik;
        }
        private int Mnozenie(int a, int b)
        {
            int wynik = a * b;
            return wynik;
        }
        private int Dzielenie(int a, int b)
        {
            int wynik = a / b;
            return wynik;
        }
        private int Potegowanie(int a) // przez 2
        {
            int wynik = a * a;
            return wynik;
        }
        private int Potegowanie(int a, int b)
        {
            double wynikTmp = Math.Pow(a,b);
            int wynik = Convert.ToInt32(wynikTmp);
            return wynik;
        }
        private int Pierwastkowanie(int a) // przez 2
        {
            int wynik = Convert.ToInt32(Math.Sqrt(a));
            return wynik;
        }
    }
}
