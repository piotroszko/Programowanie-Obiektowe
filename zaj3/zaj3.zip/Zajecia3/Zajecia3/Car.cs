﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Zajecia3
{
    class Car
    {
        public double pojemnoscSilnika;
        public string marka;
        public static int iloscKol;
        static Car() {
            iloscKol = 4;
        }
        public Car(double pojemnoscSilnika, string marka) {
            this.pojemnoscSilnika = pojemnoscSilnika;
            this.marka = marka;
            iloscKol = 4;
        }
        public Car Create() {
            Car carTmp = new Car(this.pojemnoscSilnika,this.marka);
            return carTmp;
        }

    }
}
