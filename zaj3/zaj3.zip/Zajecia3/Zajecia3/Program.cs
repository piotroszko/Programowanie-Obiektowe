﻿using System;

namespace Zajecia3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Car car1 = new Car(2000, "BMW");
            Car car2 = car1.Create();
            Console.WriteLine(car2.pojemnoscSilnika);
            Console.ReadKey();
        }
    }
}
